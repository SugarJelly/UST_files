中文

1. 感谢下载这份UST！你可以任意更改这份UST的内容。

2. 如果你使用了这份UST，即使被转化成了vsq, vsqx, svp, ustx等格式，也请在简介中注明“スガゼリ”或者“SugarJelly”或者“懒某安”，三者之一即可。

3. 如果将此工程以任何形式用于如diffsvc，sovits-svc等AI声线替换引擎的公开发布视频中，请提前联系我。

4. 关于此UST如果有任何其他疑问，可以查看文末的个人主页链接。

-----------------------------------------------------------------------------

日本語

1. このUSTのごDLありがとうございます。どうぞ気楽にお使いください。内容をいじっても構いません。

2. このUSTを使っている場合、ほかのファイル種類に変換したとしても、例えば vsq, vsqx, svp, ustxなど、「スガゼリ」或いは「SugarJelly」或いは「懒某安」をクレジットしてください。

3. このUSTにAIボイスチェンジャーなどのエンジン（diffsvc，sovits-svcなど）に使う前に、連絡してください。

4. このUSTに関わる質問があれば、下記HPのリンクでチェックしてください。

-----------------------------------------------------------------------------

English

1. Thanks for downloading this UST. Feel free to adjust anything if you wish!

2. If you use this UST, please credit スガゼリ or SugarJelly or 懒某安 in the description, even if you adapt it to other forms, including vsq, vsqx, svp, ustx, and others.

3. If you wish to publish videos using AI voice-changing engines, including diffsvc and sovits-svc etc, please contact me first.

4. If you have other questions regarding this UST, please check my personal page.


by スガゼリ



Homepage: https://sugarjelly4.top


bilibili: https://space.bilibili.com/2127802
twitter:  https://twitter.com/SugarJelly4
email:    ldhnswa@outlook.com